package es.uvigo.esei.dai.hybridserver;


public class Page {
//    Content
//    UUID
//    url

}
