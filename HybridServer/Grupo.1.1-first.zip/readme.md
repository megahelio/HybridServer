Grupo-1.1

Óscar Lestón Casais - 78810582R

Eloi Vidal Martínez-15493027C


Implementamos HTTPresponse, HTTPrequest y la interfaz dao tanto con SQL como usando un mapa, nos quedamos atascado en la semana 2 implementando serviceThread.
